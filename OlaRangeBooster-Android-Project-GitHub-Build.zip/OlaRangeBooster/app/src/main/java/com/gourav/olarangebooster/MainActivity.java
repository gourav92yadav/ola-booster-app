package com.gourav.olarangebooster;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    int bg=Color.rgb(15,25,35), card=Color.rgb(28,43,56), green=Color.rgb(42,190,125), muted=Color.rgb(170,190,205);
    EditText battery, distance, used; TextView result, scanStatus; LinearLayout deviceList;
    BluetoothLeScanner scanner; ScanCallback callback; Handler handler=new Handler(); Set<String> found=new LinkedHashSet<>();

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); buildUi(); }
    TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    GradientDrawable shape(int color){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(24); return d; }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(22,18,22,18); return l; }
    EditText field(String hint,String value){ EditText e=new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(muted); e.setInputType( android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return e; }
    void gap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,h)); }
    Button button(String label){ Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green)); return b; }
    void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(bg); LinearLayout root=column(); root.setPadding(20,28,20,28); scroll.addView(root); setContentView(scroll);
        root.addView(text("OLA RANGE BOOSTER",24,Color.WHITE,true)); root.addView(text("S1 Pro+ Gen 3 • 5.2 kWh • Range assistant",13,muted,false)); gap(root,18);
        LinearLayout hero=column(); hero.setBackground(shape(card)); root.addView(hero); hero.addView(text("ESTIMATED RANGE",12,muted,true)); result=text("Enter ride data",30,green,true); hero.addView(result); hero.addView(text("Estimate only — not live scooter telemetry",12,muted,false)); gap(root,16);
        root.addView(text("MANUAL RANGE OPTIMIZER",17,Color.WHITE,true)); root.addView(text("Battery remaining (%)",12,muted,false)); battery=field("e.g. 80","80"); root.addView(battery); root.addView(text("Distance travelled on this charge (km)",12,muted,false)); distance=field("e.g. 65","65"); root.addView(distance); root.addView(text("Battery used (%)",12,muted,false)); used=field("e.g. 50","50"); root.addView(used); Button calc=button("CALCULATE RANGE"); root.addView(calc); calc.setOnClickListener(v->calculate()); gap(root,12);
        LinearLayout modes=column(); modes.setBackground(shape(card)); root.addView(modes); modes.addView(text("RANGE DRIVING TIPS",17,Color.WHITE,true)); modes.addView(text("• Smooth acceleration; avoid sudden full throttle.\n• Keep tyre pressure at the manufacturer-recommended level.\n• Maintain steady, moderate speed.\n• Avoid unnecessary load and repeated hard braking.\n• Use regenerative braking as recommended in the vehicle settings; it cannot recover all braking energy.",14,muted,false)); gap(root,16);
        root.addView(text("BLUETOOTH SCANNER",17,Color.WHITE,true)); root.addView(text("Scans nearby BLE devices. Ola-specific live data/control is not implemented until its supported protocol/API is verified.",12,muted,false)); Button scan=button("SCAN BLUETOOTH DEVICES"); root.addView(scan); scanStatus=text("Not scanning",13,muted,false); root.addView(scanStatus); deviceList=column(); deviceList.setBackground(shape(card)); root.addView(deviceList); scan.setOnClickListener(v->startScan());
        gap(root,16); root.addView(text("Safety: This app does not write to the BMS or motor controller, unlock speed/power, or change scooter firmware. Never bypass battery protections.",12,muted,false));
    }
    void calculate(){ try { double b=Double.parseDouble(battery.getText().toString()), km=Double.parseDouble(distance.getText().toString()), u=Double.parseDouble(used.getText().toString()); if(b<0||b>100||u<=0||u>100||km<0) throw new Exception(); double per=km/u*100.0; double remain=per*b/100.0; result.setText(String.format(Locale.US,"%.1f km estimated",remain)+"\n"+String.format(Locale.US,"%.2f km per 1%% battery",per/100)); } catch(Exception ex){ result.setText("Please enter valid values"); } }
    boolean has(String p){ return Build.VERSION.SDK_INT<23 || checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED; }
    void startScan(){
        if(Build.VERSION.SDK_INT>=31 && (!has(Manifest.permission.BLUETOOTH_SCAN)||!has(Manifest.permission.BLUETOOTH_CONNECT))){ requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},22); scanStatus.setText("Allow Bluetooth permissions, then scan again."); return; }
        if(Build.VERSION.SDK_INT<31 && !has(Manifest.permission.ACCESS_FINE_LOCATION)){ requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},22); scanStatus.setText("Allow location permission for BLE scan."); return; }
        BluetoothManager manager=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE); BluetoothAdapter adapter=manager.getAdapter();
        if(adapter==null||!adapter.isEnabled()){ scanStatus.setText("Bluetooth is unavailable or switched off."); return; }
        scanner=adapter.getBluetoothLeScanner(); if(scanner==null){ scanStatus.setText("BLE scanner unavailable."); return; }
        found.clear(); deviceList.removeAllViews(); scanStatus.setText("Scanning for 12 seconds…");
        callback=new ScanCallback(){ @Override public void onScanResult(int type, ScanResult r){ BluetoothDevice d=r.getDevice(); String name="Unknown BLE device"; try{ if(d.getName()!=null)name=d.getName(); }catch(SecurityException ignored){} final String label=name+"  •  "+d.getAddress()+"  •  RSSI "+r.getRssi()+" dBm"; runOnUiThread(()->{ if(found.add(d.getAddress())) deviceList.addView(text(label,13,Color.WHITE,false)); }); } @Override public void onScanFailed(int code){runOnUiThread(()->scanStatus.setText("Scan failed: "+code));} };
        try { scanner.startScan(callback); handler.postDelayed(()->{ try{scanner.stopScan(callback);}catch(Exception ignored){} scanStatus.setText("Scan complete. Devices found: "+found.size()); },12000); } catch(SecurityException e){scanStatus.setText("Bluetooth permission denied.");}
    }
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g); if(req==22)scanStatus.setText("Permission response received. Tap Scan again.");}
    @Override protected void onDestroy(){super.onDestroy(); if(scanner!=null&&callback!=null){try{scanner.stopScan(callback);}catch(Exception ignored){}}}
}
