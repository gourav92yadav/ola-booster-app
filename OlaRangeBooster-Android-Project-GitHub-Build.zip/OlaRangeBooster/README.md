# Ola Range Booster (Android)

Android app prototype for Ola S1 Pro+ Gen 3 range estimation and BLE device discovery.

## Features in this prototype
- Manual range estimate from battery percentage and distance travelled.
- Practical range-efficiency tips.
- Bluetooth Low Energy scan for nearby BLE devices.

## Important limitations
- BLE scanning is implemented, but Ola-specific telemetry, pairing, and controller/BMS writes are **not** implemented. The app cannot change scooter tuning or battery/controller settings.
- The estimate is based on user-entered ride data; it is not live scooter telemetry.
- Do not bypass BMS, motor-controller, thermal, or speed protections.

## Build APK in GitHub Actions
1. Create a new GitHub repository and upload the contents of this folder (the `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github` folder should be at repository root).
2. Open the repository's **Actions** tab.
3. Run **Build Ola Range Booster APK** using **Run workflow**, or push to `main`/`master`.
4. When the workflow finishes, open the run and download the `Ola-Range-Booster-debug-apk` artifact.
5. Extract the artifact; install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

## Local build
Requires JDK 17, Gradle 8.9, and Android SDK Platform 35 / Build Tools 35.0.0:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
